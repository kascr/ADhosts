#!/system/bin/sh

# Magisk Module: AD_lite
# Author: Kascr/ChatGPT
# Description: Lightweight ad blocking using hosts file

SKIPUNZIP=1

ui_print "*******************************"
ui_print "     AD_lite Hosts Module      "
ui_print "*******************************"
ui_print "- Author: Kascr/ChatGPT"
ui_print "- Version: 1.0.3"
ui_print "- QQ Group: 539544651"
ui_print ""

# Check Android version
android_sdk=$(getprop ro.build.version.sdk)
ui_print "- Android SDK: $android_sdk"

# Extract module files
ui_print "- Extracting module files..."
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

# Set permissions
ui_print "- Setting permissions..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system 0 0 0755 0644
set_perm $MODPATH/system/etc/hosts 0 0 0644

# Create service.sh for boot operations
ui_print "- Creating service script..."

# Create post-fs-data.sh for early boot operations
cat > "$MODPATH/post-fs-data.sh" <<EOF
#!/system/bin/sh
# This script will be executed in post-fs-data mode
# More info in the Magisk module template

# Wait for system to be ready
sleep 5

# Backup original hosts file if not already backed up
if [ ! -f /system/etc/hosts.bak ]; then
    cp /system/etc/hosts /system/etc/hosts.bak 2>/dev/null
fi
EOF

# Create service.sh for late_start service mode
cat > "$MODPATH/service.sh" <<EOF
#!/system/bin/sh
# This script will be executed in late_start service mode
# More info in the Magisk module template

# Apply hosts file
apply_hosts() {
    # Wait for system to be fully booted
    until [ "\$(getprop sys.boot_completed)" = "1" ]; do
        sleep 1
    done
    
    # Additional wait for network
    sleep 10
    
    # Apply our hosts file
    if [ -f "$MODPATH/system/etc/hosts" ]; then
        # Mount hosts file
        mount -o bind "$MODPATH/system/etc/hosts" /system/etc/hosts
        
        # Clear DNS cache
        ndc resolver flushdefaultif || true
        ndc resolver flushif || true
        
        # For Android 7.0+
        if [ \$android_sdk -ge 24 ]; then
            iptables -t nat -F OUTPUT || true
        fi
    fi
}

# Run in background
apply_hosts &
EOF

# Set execute permissions
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755

# Create uninstall script
ui_print "- Creating uninstall script..."
cat > "$MODPATH/uninstall.sh" <<EOF
#!/system/bin/sh

# Restore original hosts file if backup exists
if [ -f /system/etc/hosts.bak ]; then
    cp /system/etc/hosts.bak /system/etc/hosts
    rm /system/etc/hosts.bak
fi

# Clear DNS cache
ndc resolver flushdefaultif || true
ndc resolver flushif || true

# Remove module files
rm -rf $MODPATH
EOF

set_perm $MODPATH/uninstall.sh 0 0 0755

# Create system directory structure
ui_print "- Creating system structure..."
mkdir -p $MODPATH/system/etc

# Copy hosts file
ui_print "- Copying hosts file..."
cp -f $MODPATH/system/etc/hosts $MODPATH/system/etc/hosts

# Check hosts file size
hosts_size=$(wc -l < "$MODPATH/system/etc/hosts")
ui_print "- Hosts file contains $hosts_size entries"

ui_print ""
ui_print "*******************************"
ui_print "    Installation Complete!     "
ui_print "*******************************"
ui_print "- Module will be active after reboot"
ui_print "- To update: Reinstall module"
ui_print "- To remove: Uninstall from Magisk"
ui_print ""
ui_print "Note: Some apps may need restart"
ui_print "      to apply ad blocking"
ui_print "*******************************"